import React, {Component} from 'react';

class AddProduct extends Component {
    render(){
        return(
            <div>
                <h2>Add Product</h2>
            </div>
        )
    }
}

export default AddProduct;