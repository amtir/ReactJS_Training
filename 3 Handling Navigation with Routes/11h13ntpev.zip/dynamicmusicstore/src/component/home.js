import React, {Component} from 'react';

class Home extends Component {
    render(){
        return(
            <div class="panel-group">
                <div class="panel panel-primary">
                    <div class="panel-heading">Home Heading</div>
                    <div class="panel-body">Home Content</div>
                </div>
                
            </div>
        )
    }
}

export default Home;