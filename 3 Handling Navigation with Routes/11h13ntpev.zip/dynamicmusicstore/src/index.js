import React from 'react';
import ReactDOM from 'react-dom';
import Routing from './component/routing';


ReactDOM.render(<Routing/>, document.getElementById('root'));