import React from 'react';

const Footer = () => {
    return(
        <footer>
            <hr/>
            <div>&copy;Edureka</div>
        </footer>
    )
}

export default Footer;