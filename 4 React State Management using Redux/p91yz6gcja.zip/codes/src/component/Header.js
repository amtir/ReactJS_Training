import React from 'react';

const Header = () => {
    return(
        <header>
            <div>Redux News</div>
        </header>
    )
}

export default Header;