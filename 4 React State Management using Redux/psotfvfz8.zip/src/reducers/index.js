import {combineReducers} from  'redux'
import food from './food_Reducers'

const rootReducer = combineReducers ({
     food
})

export default rootReducer;