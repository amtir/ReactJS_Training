export function foodItems(){
    return{

        type:'FOOD_ITEMS',
        payload:
        [
         {
             id:1, 
             name:'Donuts', 
             img :'https://images.app.goo.gl/9tGbac9oVz1qQedTA'
         },
         {   
             id:2,
             name:'Ice-cream',
             img : 'https://images.app.goo.gl/ei1hMWUmwxiMnuhR7'
         },
         {
             id:3,
             name:'Choclates',
             img : 'https://images.app.goo.gl/mGaD62DCorD3c4ucA'
        },
        ]
    }
}