import React from 'react';
import ReactDOM from 'react-dom';
import Form from './App.js';



ReactDOM.render(<Form/>, document.getElementById('root'));