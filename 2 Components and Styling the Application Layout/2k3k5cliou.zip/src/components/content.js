import React from 'react'


const Content = () => {
    return(
        
        <h3>Module 2 : Components and Styling the Application Layout  </h3>
 
    )
}                            

export default Content