import React from 'react'; 
import ReactDOM from 'react-dom'; 
import Content from './content';
import Text from './text';

class App extends React.Component{ 
	render(){ 
		return( 

				<div> 
                 
                <Text/>
				</div> 
			); 
	} 
} 

export default App